$module.template("wait-dots")`
	<template>
		<section>
			<div class="wd1"></div>
			<div class="wd2"></div>
			<div class="wd3"></div>
		</section>
	</template>
`;


$module.component("wait-dots", function() {
	return {};
});